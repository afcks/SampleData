# power-bi-sunset-visuals
Collection of Power BI custom visuals prior to the move to the Office Store
